package pet;

public class Cat extends Pet {
	
	private boolean shortHair;

	public boolean isShortHair() {
		return shortHair;
	}

	public void setShortHair(boolean shortHair) {
		this.shortHair = shortHair;
	}

}
