package quizduel1;

public interface IQuestionPool {

	Question getRandomQuestion();

}
