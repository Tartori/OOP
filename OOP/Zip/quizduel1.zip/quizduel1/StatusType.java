package quizduel1;

public enum StatusType {
    NEW, PLAYER1, PLAYER2, FINISHED;
}
