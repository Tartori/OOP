package quizduel1;

import java.util.ArrayList;

import quizduell.StatusType;

public class Duel {
	
	static int MAX_ROUND = 6;

	static int counter = 1;

	private int number;
	private Player player1;
	private Player player2;
	private Round currentRound;
	private int round_count = 1;
	private ArrayList<Round> rounds = new ArrayList<Round>();
	private StatusType status;
	private IQuestionPool pool;

	public Duel(Player currentPlayer, Player player22, IQuestionPool pool2) {
		this.number = counter++;
		this.player1 = currentPlayer;
		this.player2 = player22;
		status = StatusType.PLAYER1;
		this.pool = pool2;
		newRound();
	}

	public int getNumber() {
		return number;
	}

		public String getDescription() {
		return "Duell " + number + " : " + player1.getName() + " - "
				+ player2.getName() + " : " 
				//+ getScore(player1) + " - "
				//+ getScore(player2) + " : " 
				+ "Round: "
				+ currentRound.getNumber() + " : " + status;
	}

	public String displayCurrentRound() {
		return currentRound.getDescription();
	}

	public boolean isFinished() {
		return (this.status == StatusType.FINISHED);
	}

	private void newRound() {
		if (round_count <= MAX_ROUND) {
			currentRound = new Round(round_count,pool);
			currentRound.start();
			rounds.add(currentRound);
			round_count++;
		} else
			this.status = StatusType.FINISHED;

	}

	public boolean canBeContinued(Player currentPlayer) {
		if (currentPlayer == player1 && this.status == StatusType.PLAYER1)
			return true;
		if (currentPlayer == player2 && this.status == StatusType.PLAYER2)
			return true;
		return false;
	}
	
}
