package bookstore;

import java.util.ArrayList;

public final class BookStore {

	private ArrayList<Book> bookList;
	private String name;
	private Address address;
	
	public BookStore() {
		bookList = new ArrayList<Book>();
		name="unknown";
		address = new Address();
	}

	public BookStore(String aName, String aCity) {
		bookList = new ArrayList<Book>();
		name=aName;
		address = new Address("",aCity);
	}

	public ArrayList<Book> getBooksList() {
		return bookList;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Address getAddress() {
		return address;
	}

	public int getNmbOfBooks() {
		return bookList.size();
	}

	public void add(Book book) {
		bookList.add(book);
		
	}
}
